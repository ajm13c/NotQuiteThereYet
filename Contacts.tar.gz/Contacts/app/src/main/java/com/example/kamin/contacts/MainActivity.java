package com.example.kamin.contacts;

import android.app.Activity;
import android.database.Cursor;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private ListView lvContact;
    private ContactListAdapter adapter;
    private List<Contact> contactList;
    Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lvContact = (ListView) findViewById(R.id.listview_contact);
        //CheckBox cb = (CheckBox) findViewById(R.id.checkBox);

        contactList = new ArrayList<>();

        String name;
        String number;

        cursor = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                null,  null, null, null);
        startManagingCursor(cursor);

        int id = 1;
        while(cursor.moveToNext()) {
            name = ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME;
            number = ContactsContract.CommonDataKinds.Phone.NUMBER;

            contactList.add(new Contact(id, name, number, false));
            id = id + 1;
        }

        adapter = new ContactListAdapter(getApplicationContext(), contactList);
        lvContact.setAdapter(adapter);

        lvContact.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick( AdapterView<?> parent, View view, int position, long id){
                Toast.makeText(getApplicationContext(), "Clicked contact id: " + view.getTag(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
