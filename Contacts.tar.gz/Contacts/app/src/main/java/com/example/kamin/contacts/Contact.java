package com.example.kamin.contacts;

import android.widget.CheckBox;

/**
 * Created by kamin on 11/10/16.
 */
public class Contact {
    private int id;
    private String name;
    private String number;
    private CheckBox cb;

    public Contact(int id, String name, String number, boolean cb) {
        this.id = id;
        this.name = name;
        this.number = number;
        this.cb.setChecked(cb);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public boolean getChecked() {
        return cb.isChecked();
    }

    public void setChecked(boolean tf) {
        if(tf == false)
            if(cb.isChecked() == true)
                cb.setChecked(false);
        else
            if(cb.isChecked() == false)
                cb.setChecked(true);
    }
}
